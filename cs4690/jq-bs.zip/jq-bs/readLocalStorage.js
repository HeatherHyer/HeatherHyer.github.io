localStorage.getItem('foo');
