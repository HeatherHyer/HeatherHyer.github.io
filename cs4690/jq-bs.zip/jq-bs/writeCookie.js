document.cookie = "firstname=John";
document.cookie = "lastname=Doe; expires=Thu, 18 Dec 2013 12:00:00 UTC";
