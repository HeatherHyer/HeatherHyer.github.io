sessionStorage.getItem('foo2');
