sessionStorage.setItem('foo2', 'bar2');
