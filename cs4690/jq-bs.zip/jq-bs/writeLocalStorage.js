localStorage.setItem('foo', 'bar');
